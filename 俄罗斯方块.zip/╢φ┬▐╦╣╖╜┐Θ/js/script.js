var local = new Local();
local.start();
var remote = new Remote();
remote.start();
remote.bindEvents();